package com.example.next_step;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NextStepApplication {

    public static void main(String[] args) {
        SpringApplication.run(NextStepApplication.class, args);
    }

}
