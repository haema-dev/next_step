package com.example.next_step;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NextStepApplicationTests {

    @Test
    void contextLoads() {
    }

}
